from django.urls import path
from proveedores_app import views  

urlpatterns = [
    path('', views.inicio_vista, name='inicio'),  # La vista principal
    path('registrarProveedor/', views.registrarProveedor, name='registrarProveedor'),
    path('borrarProveedor/<idproveedor>/', views.borrarProveedor, name='borrarProveedor'),
    path('seleccionarProveedor/<idproveedor>/', views.seleccionarProveedor, name='seleccionarProveedor'),
    path('editarProveedor/', views.editarProveedor, name='editarProveedor')
]
