from django.apps import AppConfig


class PedidosAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pedidos_app'
